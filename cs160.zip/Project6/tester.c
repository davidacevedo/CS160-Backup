#include <stdio.h>

int Main_main();

int main() {
  // Call the Main_main function from the linked assembly
  Main_main();
  return 0;
}
