#!/bin/sh

echo './calculator -s  < tests/test01.txt'
./calculator -s  < tests/test01.txt
echo
echo './calculator -s  < tests/test02.txt'
./calculator -s  < tests/test02.txt
echo
echo './calculator -s  < tests/test03.txt'
./calculator -s  < tests/test03.txt
echo
echo './calculator -s  < tests/test04.txt'
./calculator -s  < tests/test04.txt
echo
echo './calculator -s  < tests/test05.txt'
./calculator -s  < tests/test05.txt
echo
echo './calculator -s  < tests/test06.txt'
./calculator -s  < tests/test06.txt
echo
echo './calculator -s  < tests/test07.txt'
./calculator -s  < tests/test07.txt
echo
echo './calculator -s  < tests/test08.txt'
./calculator -s  < tests/test08.txt
echo
echo './calculator -s  < tests/test09.txt'
./calculator -s  < tests/test09.txt
echo
echo './calculator -s  < tests/test10.txt'
./calculator -s  < tests/test10.txt
echo
echo './calculator -s  < tests/test11.txt'
./calculator -s  < tests/test11.txt
echo
echo './calculator -s  < tests/test12.txt'
./calculator -s  < tests/test12.txt
echo
echo './calculator -s  < tests/test13.txt'
./calculator -s  < tests/test13.txt
echo
echo './calculator -s  < tests/test14.txt'
./calculator -s  < tests/test14.txt
echo
echo './calculator -s  < tests/test15.txt'
./calculator -s  < tests/test15.txt
echo
echo './calculator -s  < tests/test16.txt'
./calculator -s  < tests/test16.txt
echo
echo './calculator -s  < tests/test17.txt'
./calculator -s  < tests/test17.txt
echo
echo './calculator -s  < tests/test18.txt'
./calculator -s  < tests/test18.txt
echo
echo './calculator -s  < tests/test19.txt'
./calculator -s  < tests/test19.txt
echo
echo './calculator -s  < tests/test20.txt'
./calculator -s  < tests/test20.txt
echo
echo './calculator -s  < tests/test21.txt'
./calculator -s  < tests/test21.txt
echo
echo './calculator -s  < tests/test22.txt'
./calculator -s  < tests/test22.txt
echo
echo './calculator -s  < tests/test23.txt'
./calculator -s  < tests/test23.txt
echo
echo './calculator -s  < tests/test24.txt'
./calculator -s  < tests/test24.txt
echo
echo './calculator -s  < tests/test25.txt'
./calculator -s  < tests/test25.txt
echo
echo './calculator -s  < tests/badtest01.txt'
./calculator -s  < tests/badtest01.txt
echo
echo './calculator -s  < tests/badtest03.txt'
./calculator -s  < tests/badtest03.txt
echo
echo './calculator -s  < tests/badtest04.txt'
./calculator -s  < tests/badtest04.txt
echo
echo './calculator -s  < tests/badtest05.txt'
./calculator -s  < tests/badtest05.txt
echo
echo './calculator -s  < tests/badtest06.txt'
./calculator -s  < tests/badtest06.txt
echo
echo './calculator -s  < tests/badtest07.txt'
./calculator -s  < tests/badtest07.txt
echo
echo './calculator -s  < tests/badtest08.txt'
./calculator -s  < tests/badtest08.txt
echo
echo './calculator -s  < tests/badtest13.txt'
./calculator -s  < tests/badtest13.txt
echo
echo './calculator -s  < tests/badtest15.txt'
./calculator -s  < tests/badtest15.txt
echo
echo './calculator < tests/test01.txt'
./calculator < tests/test01.txt
echo
echo './calculator < tests/test02.txt'
./calculator < tests/test02.txt
echo
echo './calculator < tests/test03.txt'
./calculator < tests/test03.txt
echo
echo './calculator < tests/test04.txt'
./calculator < tests/test04.txt
echo
echo './calculator < tests/test05.txt'
./calculator < tests/test05.txt
echo
echo './calculator < tests/test06.txt'
./calculator < tests/test06.txt
echo
echo './calculator < tests/test07.txt'
./calculator < tests/test07.txt
echo
echo './calculator < tests/test08.txt'
./calculator < tests/test08.txt
echo
echo './calculator < tests/test09.txt'
./calculator < tests/test09.txt
echo
echo './calculator < tests/test10.txt'
./calculator < tests/test10.txt
echo
echo './calculator < tests/test11.txt'
./calculator < tests/test11.txt
echo
echo './calculator < tests/test12.txt'
./calculator < tests/test12.txt
echo
echo './calculator < tests/test13.txt'
./calculator < tests/test13.txt
echo
echo './calculator < tests/test14.txt'
./calculator < tests/test14.txt
echo
echo './calculator < tests/test15.txt'
./calculator < tests/test15.txt
echo
echo './calculator < tests/test16.txt'
./calculator < tests/test16.txt
echo
echo './calculator < tests/test17.txt'
./calculator < tests/test17.txt
echo
echo './calculator < tests/test18.txt'
./calculator < tests/test18.txt
echo
echo './calculator < tests/test19.txt'
./calculator < tests/test19.txt
echo
echo './calculator < tests/test20.txt'
./calculator < tests/test20.txt
echo
echo './calculator < tests/test21.txt'
./calculator < tests/test21.txt
echo
echo './calculator < tests/test22.txt'
./calculator < tests/test22.txt
echo
echo './calculator < tests/test23.txt'
./calculator < tests/test23.txt
echo
echo './calculator < tests/test24.txt'
./calculator < tests/test24.txt
echo
echo './calculator < tests/test25.txt'
./calculator < tests/test25.txt
echo
echo './calculator < tests/badtest01.txt'
./calculator < tests/badtest01.txt
echo
echo './calculator < tests/badtest03.txt'
./calculator < tests/badtest03.txt
echo
echo './calculator < tests/badtest04.txt'
./calculator < tests/badtest04.txt
echo
echo './calculator < tests/badtest05.txt'
./calculator < tests/badtest05.txt
echo
echo './calculator < tests/badtest06.txt'
./calculator < tests/badtest06.txt
echo
echo './calculator < tests/badtest07.txt'
./calculator < tests/badtest07.txt
echo
echo './calculator < tests/badtest08.txt'
./calculator < tests/badtest08.txt
echo
echo './calculator < tests/badtest13.txt'
./calculator < tests/badtest13.txt
echo
echo './calculator < tests/badtest15.txt'
./calculator < tests/badtest15.txt
echo
echo './calculator -e < tests/evaluation/goodtest01.txt'
./calculator -e < tests/evaluation/goodtest01.txt
echo
echo './calculator -e < tests/evaluation/goodtest02.txt'
./calculator -e < tests/evaluation/goodtest02.txt
echo
echo './calculator -e < tests/evaluation/goodtest03.txt'
./calculator -e < tests/evaluation/goodtest03.txt
echo
echo './calculator -e < tests/evaluation/goodtest04.txt'
./calculator -e < tests/evaluation/goodtest04.txt
echo
echo './calculator -e < tests/evaluation/goodtest05.txt'
./calculator -e < tests/evaluation/goodtest05.txt
echo
echo './calculator -e < tests/evaluation/goodtest06.txt'
./calculator -e < tests/evaluation/goodtest06.txt
echo
echo './calculator -e < tests/evaluation/goodtest07.txt'
./calculator -e < tests/evaluation/goodtest07.txt
echo
echo './calculator -e < tests/evaluation/goodtest08.txt'
./calculator -e < tests/evaluation/goodtest08.txt
echo
echo './calculator -e < tests/evaluation/goodtest09.txt'
./calculator -e < tests/evaluation/goodtest09.txt
echo
echo './calculator -e < tests/evaluation/goodtest10.txt'
./calculator -e < tests/evaluation/goodtest10.txt
echo
echo './calculator -e < tests/evaluation/goodtest11.txt'
./calculator -e < tests/evaluation/goodtest11.txt
echo
echo './calculator -e < tests/evaluation/goodtest12.txt'
./calculator -e < tests/evaluation/goodtest12.txt
echo
echo './calculator -e < tests/evaluation/goodtest13.txt'
./calculator -e < tests/evaluation/goodtest13.txt
echo
echo './calculator -e < tests/evaluation/goodtest14.txt'
./calculator -e < tests/evaluation/goodtest14.txt
echo
echo './calculator -e < tests/evaluation/goodtest15.txt'
./calculator -e < tests/evaluation/goodtest15.txt
echo
echo './calculator -e < tests/evaluation/goodtest16.txt'
./calculator -e < tests/evaluation/goodtest16.txt
echo
echo './calculator -e < tests/evaluation/badtest02.txt'
./calculator -e < tests/evaluation/badtest02.txt
echo
echo './calculator -e < tests/evaluation/badtest09.txt'
./calculator -e < tests/evaluation/badtest09.txt
echo
echo './calculator -e < tests/evaluation/badtest10.txt'
./calculator -e < tests/evaluation/badtest10.txt
echo
echo './calculator -e < tests/evaluation/badtest11.txt'
./calculator -e < tests/evaluation/badtest11.txt
echo
echo './calculator -e < tests/evaluation/badtest12.txt'
./calculator -e < tests/evaluation/badtest12.txt
echo
echo './calculator -e < tests/evaluation/badtest14.txt'
./calculator -e < tests/evaluation/badtest14.txt
echo