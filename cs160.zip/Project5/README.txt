David Acevedo
6758304
davidacevedo@umail.ucsb.edu
Ok, there should be no more corner cases, hopefully, this is the final turnin ok bye
